def kwic(document, listPairs=False, ignoreWords=[]):
    if not document:
        return []

    return [document]