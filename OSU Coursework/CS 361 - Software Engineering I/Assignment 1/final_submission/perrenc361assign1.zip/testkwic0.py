from kwic import kwic

document = ""                       # Input no data

if __name__ == "__main__":
    assert(kwic(document) == [])    # Ensure that results are empty because there's no data