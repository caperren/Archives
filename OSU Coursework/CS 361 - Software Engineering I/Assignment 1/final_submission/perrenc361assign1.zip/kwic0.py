def kwic(document, listPairs=False, ignoreWords=[]):
    return []